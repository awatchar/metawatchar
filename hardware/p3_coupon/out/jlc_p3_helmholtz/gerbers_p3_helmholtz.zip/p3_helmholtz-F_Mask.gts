%TF.GenerationSoftware,KiCad,Pcbnew,10.0.6*%
%TF.CreationDate,2026-10-23T13:56:32+07:00*%
%TF.ProjectId,p3_helmholtz,70335f68-656c-46d6-986f-6c747a2e6b69,rev?*%
%TF.SameCoordinates,Original*%
%TF.FileFunction,Soldermask,Top*%
%TF.FilePolarity,Negative*%
%FSLAX46Y46*%
G04 Gerber Fmt 4.6, Leading zero omitted, Abs format (unit mm)*
G04 Created by KiCad (PCBNEW 10.0.6) date 2026-10-23 13:56:32*
%MOMM*%
%LPD*%
G01*
G04 APERTURE LIST*
%ADD10C,3.200000*%
%ADD11R,1.700000X1.700000*%
%ADD12C,1.700000*%
G04 APERTURE END LIST*
D10*
%TO.C,H3*%
X7000000Y-103000000D03*
%TD*%
%TO.C,H4*%
X103000000Y-103000000D03*
%TD*%
D11*
%TO.C,J1*%
X104000000Y-55000000D03*
D12*
X104000000Y-57540000D03*
%TD*%
D10*
%TO.C,H2*%
X103000000Y-7000000D03*
%TD*%
%TO.C,H1*%
X7000000Y-7000000D03*
%TD*%
M02*
